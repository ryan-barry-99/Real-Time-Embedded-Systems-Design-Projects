/*
 * servo.c
 *
 *  Created on: Sep 28, 2022
 *      Author: Ryan Barry
 */
#include <stdlib.h>
#include "servo.h"
#include "tim.h"
#include "recipes.h"
#include "MFS.h"
#include "app.h"
// Initialize servo0's struct and its variables
struct servo servo0 = {	.id = 0,
						.counter = 0,
						.recipe_choice = 0,
						.move_flag = 0,
						.pause_flag = 1,
						.recipe_end_flag = 0,
						.recipe_command_error_flag = 0,
						.nested_loop_error_flag = 0,
						.active_loop_flag = 0,
						.custom_opcode_flag = 0};
// Initialize servo1's struct and its variables
struct servo servo1 = {	.id = 1,
						.counter = 0,
						.recipe_choice = 0,
						.move_flag = 0,
						.pause_flag = 1,
						.recipe_end_flag = 0,
						.recipe_command_error_flag = 0,
						.nested_loop_error_flag = 0,
						.active_loop_flag = 0,
						.custom_opcode_flag = 0};
struct servo *servo; // Create a servo struct pointer to be used to point to servo1 and servo2
extern unsigned char *recipes[]; // Include the array of recipes from servo.c


// Functions that set the servo positions to their predetermined values 0 through 5,
// with 0 being the most clockwise location and 5 being the most counterclockwise location
void set_servos(void)
{
	for(int i=0;i<2; i++) // 2 iteration for loop to set the position clock value for both servos
	{
		if(i == 0)
			servo = &servo0; // Set the servo pointer to the servo of the current i value
		else if(i == 1)
			servo = &servo1;
		if((servo->target_position == pos_0 || servo->target_position <= pos_5) && servo->move_flag == 1) // Only change the position clock if the target position is real and the move flag is high
		{
			for(int j=0;j<=servo->target_position; j++)
			{
				servo->position_clock = 1600 + 1450*j; // Set position_clock to that of the new target position
			}
			servo->move_flag = 0;
			servo_state[i] = servo->target_position; // Update the new position
		}
	}
	TIM3->CCR1 = servo0.position_clock; // Move position_clock value into timer CCR
	TIM3->CCR2 = servo1.position_clock;
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1); // Start the PWM signal
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
}

// Initializes state variables and anything else need to drive servo
//   num - the servo number to initialize
//   recipe_num - the recipe this servo is to run
void SERVO_init(int num, int recipe_num)
{
	servo->action = recipes[recipe_num][servo->servo_recipe_iterator]; // Action is the entire instruction containing the opcode and parameter
	servo->opcode = servo->action &  0xE0;		// Determine the opcode by bitwise ANDing b7, b6, b5 with 1
	servo->parameter = servo->action & 0x1F;	// Determine the parameter by bitwise ANDing b4, b3, b2, b1, and b0 with 1
}

// Updates the servo state variables with a user command, if any.
void SERVO_set_user_command(int num, int command)
{
	switch(command) // Updates to servo functionality based on user input
	{
	case pause_recipe: // Raise the pause flag and turn off the recipe active LED if the recipe hasn't ended yet
		if(servo->recipe_end_flag == 0)
		{
			servo->pause_flag = 1;
			MFS_set_led(num+1,0); 	// Turn off LED
		}
		break;
	case continue_recipe: // Lower the pause flag if the recipe hasn't ended and continue the recipe from where it left off
		if(servo->recipe_end_flag == 0){
			servo->pause_flag = 0;
			SERVO_init(num, servo->recipe_choice);
		}
		break;

	case move_right: // If the recipe is paused move the servo one position to the right if possible
		if(servo_state[num] > pos_0 && servo_state[num] != state_unknown
				&& servo->pause_flag == 1)
		{
			servo->target_position = servo_state[num] - 1;
			servo_state[num] = state_moving;
			servo->move_flag = 1;
		}
		servo->user_command = no_op;
		break;
	case move_left: // If the recipe is paused move the servo one position to the left if possible
		if(servo_state[num] < pos_5 && servo_state[num] != state_unknown
				&& servo->pause_flag == 1)
		{
			servo->target_position = servo_state[num] + 1;
			servo_state[num] = state_moving;
			servo->move_flag = 1;
		}
		servo->user_command = no_op; // User command has no effect on the servo
		break;
	case no_op:
		SERVO_init(num, servo->recipe_choice);
		break;
	case begin_recipe: // Set servo to its initial conditions and start execution`
		servo->pause_flag = 0;
		servo->recipe_command_error_flag = 0;
		servo->servo_recipe_iterator = 0;
		servo->user_command = continue_recipe;
		SERVO_init(num, servo->recipe_choice);
		servo->recipe_end_flag = 0;
		command = continue_recipe; // Command set to continue_recipe so it doesn't come back to begin_recipe in the next loop
		break;
	case new_recipe: // Reset error flags and error LEDs because the recipe has changed
		servo->recipe_command_error_flag = 0;
		servo->nested_loop_error_flag = 0;
		MFS_set_led(3,0);
		MFS_set_led(4,0);
		servo->user_command = no_op;
		break;
	default:
		SERVO_init(num, servo->recipe_choice); // Check recipe index and move on
		break;
	}
}

// Run the state machine for servo `num`.
void SERVO_process(unsigned int num, unsigned int recipe_i)
{

	if(num == 0) // Set the servo pointer to point to the correct servo for this function call
		servo = &servo0;
	else if(num == 1)
		servo = &servo1;
	servo->recipe_choice = recipe_i; // chosen recipe set to the recipe index

	SERVO_set_user_command(num, servo->user_command);//, servo->recipe_choice);

	if(	servo->recipe_end_flag == 0 // Only execute recipe instruction if recipe not paused, not finished, and no errors
		&& servo->pause_flag == 0
		&& servo->recipe_command_error_flag == 0
		&& servo->nested_loop_error_flag == 0)
	{
		MFS_set_led(num+1,1); // Turn on active recipe LED and turn off error LEDs
		MFS_set_led(3,0);
		MFS_set_led(4,0);
		switch(servo->opcode) // Process the current opcode
		{
		case MOV:
			if(servo->parameter < 0 || servo->parameter > 5) // Check for out of bounds parameter error
			{
				servo->recipe_command_error_flag = 1; // Raise flag and turn on recipe error LED if parameter out of bounds
				MFS_set_led(3, 1);
			}
			else if(servo->counter < 2*abs(servo->parameter - servo_state[num])){ 	// Needs enough time ot move to next position
				servo_state[num] = state_moving;	// Update the most recent position
				servo->move_flag = 1; 						// Set the move flag
				servo->target_position = servo->parameter;	// Set the target position to the parameter
				servo->counter++;							// Increase the counter
			}
			else{ // Move to next state
				servo->servo_recipe_iterator++;
				servo->counter = 0;
				SERVO_process(num, recipe_i);
			}
			break;

		case WAIT:
			if(servo->parameter < 0 || servo->parameter > 31) // Check for out of bounds parameter error
			{
				servo->recipe_command_error_flag = 1; // Raise flag and turn on recipe error LED if parameter out of bounds
				MFS_set_led(3, 1);
			}
			else if(servo->counter < servo->parameter)
				servo->counter++; // App has waited for 100 ms
			else{ // Move to next state
				servo->servo_recipe_iterator++;
				servo->counter = 0;
				SERVO_process(num, recipe_i);
			}
			break;

		case LOOP:
			if(servo->active_loop_flag == 1) // Check for nested loop error
			{
				servo->nested_loop_error_flag = 1; // Raise flag and turn on nested loop error LED if nested loops are detected
				MFS_set_led(4, 1);
			}
			else if(servo->parameter < 0 || servo->parameter > 31) // Check for out of boundsparameter error
			{
				servo->recipe_command_error_flag = 1; // Raise flag and turn on LED if parameter out of bounds
				MFS_set_led(3, 1);
			}
			else{
				servo->active_loop_flag = 1; // Raise flag to indicate a loop is active
				servo->loop_begin = servo->servo_recipe_iterator+1; // Move to next recipe command
				servo->loop_iterations = servo->parameter;	// The number of additional times to execute the following recipe block
				servo->servo_recipe_iterator++;
				servo->counter = 0;
				SERVO_process(num, recipe_i);
			}
			break;

		case LOOP_END:
			if(	servo->loop_iterations > 0){ // Repeat loop if not ended
				servo->active_loop_flag = 0; // Lower active loop flag if loop has ended and move to next recipe command
				servo->servo_recipe_iterator = servo->loop_begin;
				servo->counter = 0;
				servo->loop_iterations--;
				SERVO_process(num, recipe_i);
			}
			else
				servo->servo_recipe_iterator++;
			break;

		case RECIPE_END: // Turn off recipe LED and raise recipe_end_flag
			MFS_set_led(num+1,0);	// Turn off LED 1
			servo_state[num] = state_recipe_ended;
			servo->recipe_end_flag = 1;
			break;

		case CROSS: // Custom opcode that moves to the closest (parameter == 0) or furthest (parameter == 1) extreme position

			if(servo->parameter < 0 || servo->parameter > 1) // Check if parameter is out of range
			{
				servo->recipe_command_error_flag = 1; // Raise recipe error flag and turn on LED
				MFS_set_led(3, 1);
			}
			else{
				if(	   servo->custom_opcode_flag == 0 // Logic to moving to position 0
					&& ((servo->parameter == 0 && servo_state[num] <= pos_2)
					|| (servo->parameter == 0 && servo_state[num] == state_unknown)
					|| (servo->parameter == 1 && servo_state[num] > pos_2 && servo_state[num] != state_unknown)))
				{
					servo->target_position = pos_0;
					servo->move_flag = 1;
					servo->custom_opcode_flag = 1; // Flag for making sure it's fully across
				}
				else if(   servo->custom_opcode_flag == 0 // Logic for moving to position 5
						&& ((servo->parameter == 1 && servo_state[num] <= pos_2)
						|| (servo->parameter == 1 && servo_state[num] == state_unknown)
						|| (servo->parameter == 0 && servo_state[num] > pos_2 && servo_state[num] != state_unknown)))
				{
					servo->target_position = pos_5;
					servo->move_flag = 1;
					servo->custom_opcode_flag = 1; // Flag to make sure it's fully across
				}
				if(servo->counter < 5){ // Cross takes 500 ms every time no matter the position
					servo_state[num] = state_moving;	// Update the most recent position
					servo->move_flag = 1;
					servo->counter++;
				}
				else{
					servo->servo_recipe_iterator++; // Move to next recipe command
					servo->counter = 0;
					SERVO_process(num, recipe_i);
					servo->custom_opcode_flag = 0;
				}
			}

			break;
		case ILLEGAL_1: // Illegal opcodes raise recipe error
		case ILLEGAL_2:
			servo->recipe_command_error_flag = 1;
			MFS_set_led(3,1);
			break;
		}
	}
	else if(servo->recipe_command_error_flag == 1) // Turn on LEDs for error states
		MFS_set_led(3,1);
	else if(servo->nested_loop_error_flag == 1)
		MFS_set_led(4,1);
}
