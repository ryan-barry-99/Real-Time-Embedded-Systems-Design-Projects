/*
 * recipes.c
 *
 *  Created on: Sep 28, 2022
 *      Author: Ryan Barry
 */


#include "recipes.h"

unsigned char recipe0[] = { MOV  | 0,	WAIT | 5,	// Check all positions and wait times
							MOV  | 1,	WAIT | 4,
							MOV  | 2,	WAIT | 3,
							MOV  | 3, 	WAIT | 2,
							MOV  | 4, 	WAIT | 1,
							MOV  | 5,
							LOOP | 4,	// Test the default loop behavior.
								MOV  | 1,
								WAIT | 5,
								MOV  | 5,	  // Is there full travel?
							LOOP_END,
							MOV  | 0,
							WAIT | 31,	// Measure the timing precision of the
							WAIT | 31,	// 9.6 second delay with an
							WAIT | 31,	// external timer.
							MOV  | 4,
							RECIPE_END };


unsigned char recipe1[] = { MOV  | 0, 	WAIT | 1,
							MOV  | 1, 	WAIT | 1,
							MOV  | 2, 	WAIT | 1,
							RECIPE_END,
							MOV  | 3, 	WAIT | 1,
							MOV  | 4, 	WAIT | 1,
							MOV  | 5 };

unsigned char recipe2[] = { MOV | 0,	WAIT | 5,
							MOV | 1,	WAIT | 5,
							MOV | 2,	WAIT | 5,
							MOV | 3,	WAIT | 5,
							MOV | 4,	WAIT | 5,
							MOV | 5 };

unsigned char recipe3[] = { MOV | 0,	WAIT | 5,
							MOV | 1,	WAIT | 5,
							MOV | 2,
							RECIPE_END,
							MOV | 3,	WAIT | 5,
							MOV | 4,	WAIT | 5,
							MOV | 5 };

unsigned char recipe4[] = { MOV | 0,	WAIT | 5,
							MOV | 1,	WAIT | 5,
							MOV | 2,	WAIT | 5,
							MOV | 7,
							MOV | 3,	WAIT | 5,
							MOV | 4,	WAIT | 5,
							MOV | 5 };

unsigned char recipe5[] = { LOOP,
								MOV | 0,	WAIT | 5,
								MOV | 1,	WAIT | 5,
								LOOP,
									MOV | 2,	WAIT | 5,
									MOV | 3,	WAIT | 5,
								LOOP_END,
								MOV | 4,	WAIT | 5,
								MOV | 5,	WAIT | 5,
							LOOP_END };

unsigned char recipe6[] = { MOV | 0,	WAIT | 5,
							CROSS | 1,
							MOV | 1,	WAIT | 5,
							CROSS | 0,
							MOV | 2,	WAIT | 5,
							CROSS | 1,
							MOV | 3,	WAIT | 5,
							CROSS | 0,
							MOV | 4,	WAIT | 5,
							CROSS | 1,
							MOV | 5,	WAIT | 5,
							CROSS | 0 };

unsigned char recipe7[] = { CROSS | 1,
							CROSS | 0,
							CROSS | 1,
							CROSS | 0,
							CROSS | 1,
							CROSS | 0 };

unsigned char recipe8[] = { CROSS | 1,
							CROSS | 1,
							CROSS | 1,
							CROSS | 0,
							CROSS | 2,
							CROSS | 0 };

unsigned char recipe9[] = { MOV | 0,	WAIT | 5,
							CROSS | 0,	WAIT | 5,
							MOV | 1,	WAIT | 5,
							CROSS | 1,	WAIT | 5,
							MOV | 2,	WAIT | 5,
							CROSS | 0,	WAIT | 5,
							MOV | 3,	WAIT | 5,
							CROSS | 1,	WAIT | 5,
							MOV | 4,	WAIT | 5,
							CROSS | 0,	WAIT | 5,
							MOV | 5,	WAIT | 5,
							CROSS | 1 };
// If you set up an array like this then you can easily switch recipes
// using an additional user input command.
unsigned char *recipes[] = { recipe0, recipe1, recipe2, recipe3, recipe4, recipe5, recipe6, recipe7, recipe8, recipe9 } ;

