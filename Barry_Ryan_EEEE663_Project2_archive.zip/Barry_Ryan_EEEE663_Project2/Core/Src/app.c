/*
 * app.c
 *
 *  Created on: Sep 28, 2022
 *      Author: Ryan Barry
 */
#include "app.h"
#include "usart.h"
#include "servo.h"
#include <stdlib.h>
#include <string.h>

extern struct servo servo0;
extern struct servo servo1;
extern struct servo *servo;
//static unsigned int user_cmd[2] = {pause_recipe, pause_recipe};
//unsigned int user_command[2] = {pause_recipe, pause_recipe};
extern uint8_t buffer[];
extern _Bool new_command;
//extern _Bool move_flag[];
//extern int parameter[];


extern uint8_t Rx_data[10];  //  creating a buffer of 10 bytes

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  HAL_UART_Receive_IT(&huart2, Rx_data, 3);
}


void app_loop(void)
{
//	uint8_t* buf = buffer;
	new_command = get_line((uint8_t *) buffer,3);

	if(new_command)
	{
		//HAL_UART_Transmit(&huart2, Rx_data, 3, 1);
		process_user_command();
	}
	SERVO_process(servo0.id, servo0.recipe_choice);
	SERVO_process(servo1.id, servo1.recipe_choice);
	set_servos();
	HAL_Delay(100);
}

//Iterates over the buffer to extract the user command and adds it to the servo structs.
void process_user_command(void)
{
	for(int i=0; i<2; i++)
	{
		if(i==0)
			servo = &servo0;
		else if(i==1)
			servo = &servo1;
		switch(buffer[i])
		{
			case 'P':
			case 'p':
				servo->user_command = pause_recipe;
				break;
			case 'C':
			case 'c':
				servo->user_command = continue_recipe;
				break;
			case 'R':
			case 'r':
				servo->user_command = move_right;
				break;
			case 'L':
			case 'l':
				servo->user_command = move_left;
				break;
			case 'N':
			case 'n':
				servo->user_command = no_op;
				break;
			case 'B':
			case 'b':
				servo->user_command = begin_recipe;
				break;
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				servo->user_command = new_recipe;
				servo->recipe_choice = buffer[i] - 48;
				servo->servo_recipe_iterator = 0;
				servo->nested_loop_error_flag = 0;
				servo->recipe_command_error_flag = 0;
				servo->active_loop_flag = 0;

				break;
		}
//		servo->user_command = servo->user_cmd;
	}
}



//void app_loop(void)
//{
////	uint8_t* buf = buffer;
//	new_command = get_line((uint32_t *) buffer,3);
//
//	if(new_command)
//	{
//		//HAL_UART_Transmit(&huart2, Rx_data, 3, 1);
//		process_user_command();
//	}
//	SERVO_process(0, 1);
//	SERVO_process(1, 1);
//	set_servos(parameter[0], parameter[1]);
//	HAL_Delay(100);
//}
//
//void process_user_command(void)
//{
//	for(int i=0; i<2; i++)
//	{
//		switch(buffer[i])
//		{
//			case 'P':
//			case 'p':
//				user_cmd[i] = pause_recipe;
//				break;
//			case 'C':
//			case 'c':
//				user_cmd[i] = continue_recipe;
//				break;
//			case 'R':
//			case 'r':
//				user_cmd[i] = move_right;
//				break;
//			case 'L':
//			case 'l':
//				user_cmd[i] = move_left;
//				break;
//			case 'N':
//			case 'n':
//				user_cmd[i] = no_op;
//				break;
//			case 'B':
//			case 'b':
//				user_cmd[i] = begin_recipe;
//				break;
//			case '0':
//			case '1':
//			case '2':
//			case '3':
//			case '4':
//			case '5':
//			case '6':
//			case '7':
//			case '8':
//			case '9':
//				user_cmd[i] = new_recipe;
//				break;
//		}
//		user_command[i] = user_cmd[i];
//	}
//}
