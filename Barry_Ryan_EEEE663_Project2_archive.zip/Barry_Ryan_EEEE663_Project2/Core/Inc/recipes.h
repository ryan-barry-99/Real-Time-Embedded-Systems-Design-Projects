/*
 * recipes.h
 *
 *  Created on: Sep 28, 2022
 *      Author: Ryan Barry
 */

#ifndef INC_RECIPES_H_
#define INC_RECIPES_H_

#define MOV 0x20
#define WAIT 0x40
#define LOOP 0x80
#define LOOP_END 0xA0
#define RECIPE_END 0x00
#define CROSS 0x60
#define ILLEGAL_1 0XC0
#define ILLEGAL_2 0XE0
// This is a good way to define the status of the display.
// This should be in a header (.h) file.
enum status
{
	status_running,
	status_paused,
	status_command_error,
	status_nested_error
} ;


// This is a good way to define the event transitions between states.
// This also should be in a header (.h) file.
// More events are needed.
enum events
{
	user_entered_left,
	recipe_ended
} ;


#endif /* INC_RECIPES_H_ */
