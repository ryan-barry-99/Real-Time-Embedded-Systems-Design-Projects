/*
 * servo.h
 *
 *  Created on: Sep 28, 2022
 *      Author: Ryan Barry
 */

#ifndef SRC_SERVO_H_
#define SRC_SERVO_H_

#include "stm32l4xx_hal.h"


// This is a good way to define the state of a servo motor.
// This should be in a header (.h) file.
enum servo_states
{
	pos_0, // use a separate integer to record the current position (0 through 5) for each servo.
	pos_1,
	pos_2,
	pos_3,
	pos_4,
	pos_5,
	state_unknown,
	state_moving,
	state_recipe_ended
} ;

// Define a "global" state value that is only accessible in one .c module (static makes it "private").
// Define the initial state as paused.
static enum servo_states servo_state[2] = {state_unknown, state_unknown};

// Struct containing all of the servo variables
struct servo
{
	unsigned int id;					// Holds the servo number
	unsigned int recipe_choice;			// Holew the active recipe number
	unsigned int user_command;			// Holds the current user command
	unsigned int action;				// Holds the current recipe instruction
	unsigned int opcode;				// Holds the current recipe instruction's opcode
	unsigned int parameter;				// Holds the current recupe instruction's parameter
	unsigned int target_position;		// Holds the target position to move to
	int servo_recipe_iterator;			// Holds the current recipe instruction's index
	int loop_begin;						// Holds the index value of the beginning of a loop
	int loop_iterations;				// Holds the number of loops left to complete
	unsigned int counter;				// Holds the number of app loop counts to remain at a recipe instruction
	int position_clock;					// Holds the value to go into TIM3's CCRx register for a new servo position
	_Bool move_flag;					// Flag raised to move to a new position
	_Bool pause_flag;					// Flag raised to pause recipe
	_Bool recipe_end_flag;				// Flag raised at the end of a recipe
	_Bool recipe_command_error_flag;	// Flag raised upon a recipe command error
	_Bool nested_loop_error_flag;		// Flag raised upon a nested loop error
	_Bool active_loop_flag;				// Flag raised while a loop is in execution
	_Bool custom_opcode_flag;			// Flag raised while servo is in CROSS opcode

};


extern struct servo servo0;
extern struct servo servo1;
extern struct servo *servo;

void set_servos(void);

// Initializes state variables and anything else need to drive servo
//   num - the servo number to initialize
//   recipe_num - the recipe this servo is to run
void SERVO_init(int num, int recipe_num);

// Updates the servo state variables with a user command, if any.
void SERVO_set_user_cmd(int num, int command);//,  unsigned int recipe_i);

// Run the state machine for servo `num`.
void SERVO_process(unsigned int num, unsigned int recipe_i);


#endif /* SRC_SERVO_H_ */
