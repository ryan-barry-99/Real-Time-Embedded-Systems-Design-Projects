/*
 * app.h
 *
 *  Created on: Sep 28, 2022
 *      Author: Ryan Barry
 */

#ifndef INC_APP_H_
#define INC_APP_H_

#define pause_recipe 0
#define continue_recipe 1
#define move_right 2
#define move_left 3
#define no_op 4
#define begin_recipe 5
#define new_recipe 6
//extern int user_cmd[2];

void app_loop(void);



void process_user_command(void);

//enum user_command
//{
//	begin_recipe,
//	continue_recipe,
//	pause_recipe,
//	move_right,
//	move_left,
//	no_op,
//	new_recipe
//};
//
//static enum user_command user_cmd[2];
#endif /* INC_APP_H_ */
